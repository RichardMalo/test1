from flask import Flask
from flask_sqlalchemy import SQLAlchemy
import csv

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
db = SQLAlchemy(app)  # Define the db variable and pass the app object to it

class Data(db.Model):
    yr = db.Column(db.Integer, primary_key=True)
    mag = db.Column(db.Integer)
    inj = db.Column(db.Integer)
    fat = db.Column(db.Integer)

    @staticmethod
    def load_data():
        with app.app_context():
            with open('data/YrMagInjFat_tornadoes.csv', newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    data = Data(yr=int(row['yr']), mag=int(row['mag']), inj=int(row['inj']), fat=int(row['fat']))
                    db.session.add(data)
            db.session.commit()

Data.load_data()

data = Data.query.all()
for d in data:
    print(d.yr, d.mag, d.inj, d.fat)
